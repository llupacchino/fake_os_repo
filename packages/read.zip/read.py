import time

def tail(file_path, n=10):
    with open(file_path, 'r') as f:
        lines = f.readlines()
        return lines[-n:]

def follow(file_path):
    with open(file_path, 'r') as f:
        f.seek(0, 2)  # Move to the end of the file
        while True:
            line = f.readline()
            if not line:
                time.sleep(0.1)
                continue
            print(line, end='')

def read_command(args):
    if len(args) == 0:
        print("Usage: read -t <file> or read -f <file>")
        return

    command = args[0]
    if command == '-t':
        if len(args) < 2:
            print("Usage: read -t <file>")
        else:
            lines = tail(args[1])
            for line in lines:
                print(line, end='')
    elif command == '-f':
        if len(args) < 2:
            print("Usage: read -f <file>")
        else:
            follow(args[1])
    else:
        print(f"Unknown command: {command}")

def register(shell):
    shell.commands['read'] = read_command
